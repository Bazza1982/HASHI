from __future__ import annotations

import json

from fastapi.testclient import TestClient

from remote.api.server import create_app
from remote.protocol_manager import ProtocolManager
from remote.security.pairing import PairingManager
from remote.terminal.executor import AuthLevel, TerminalExecutor


def test_status_reads_pid_from_controlled_root(tmp_path):
    runtime_root = tmp_path / "watchtower"
    controlled_root = tmp_path / "hashi9"
    runtime_root.mkdir()
    controlled_root.mkdir()
    (controlled_root / ".bridge_u_f.pid").write_text("99999999", encoding="utf-8")

    app = create_app(
        {"instance_id": "WATCHTOWER"},
        PairingManager(storage_dir=runtime_root / "pairing", lan_mode=True),
        TerminalExecutor(max_allowed_level=AuthLevel.L2_WRITE),
        hashi_root=str(runtime_root),
        controlled_root=str(controlled_root),
        workbench_port=1,
    )
    client = TestClient(app)

    response = client.get("/control/hashi/status")

    assert response.status_code == 200
    body = response.json()
    assert body["state"] == "stale_pid"
    assert body["pid_file_exists"] is True
    assert body["pid"] == 99999999


def test_logs_stay_under_watchtower_runtime_root(tmp_path):
    runtime_root = tmp_path / "watchtower"
    controlled_root = tmp_path / "hashi9"
    (runtime_root / "logs").mkdir(parents=True)
    controlled_root.mkdir()
    (runtime_root / "logs" / "remote_rescue_hashi_start.log").write_text("alpha\nbeta\n", encoding="utf-8")

    app = create_app(
        {"instance_id": "WATCHTOWER"},
        PairingManager(storage_dir=runtime_root / "pairing", lan_mode=True),
        TerminalExecutor(max_allowed_level=AuthLevel.L2_WRITE),
        hashi_root=str(runtime_root),
        controlled_root=str(controlled_root),
        workbench_port=1,
    )
    client = TestClient(app)

    response = client.get("/control/hashi/logs?name=start&tail=5")

    assert response.status_code == 200
    body = response.json()
    assert body["lines"] == ["alpha", "beta"]
    assert "watchtower" in body["path"]


def test_protocol_manager_reads_agent_snapshot_from_controlled_root(tmp_path):
    runtime_root = tmp_path / "watchtower"
    controlled_root = tmp_path / "hashi9"
    runtime_root.mkdir()
    controlled_root.mkdir()
    (controlled_root / "agents.json").write_text(
        json.dumps(
            {
                "global": {"instance_id": "HASHI9", "display_name": "HASHI9 (Windows)"},
                "agents": [{"name": "hashiko", "display_name": "Hashiko", "is_active": True}],
            }
        ),
        encoding="utf-8",
    )

    protocol = ProtocolManager(
        hashi_root=runtime_root,
        agent_root=controlled_root,
        instance_info={"instance_id": "WATCHTOWER", "display_name": "HASHI WatchTower"},
        peer_registry=None,
        workbench_port=1,
        local_capabilities=["rescue_control"],
        use_tls=False,
    )

    snapshot = protocol.get_local_agents_snapshot()

    assert any(agent["agent_name"] == "hashiko" for agent in snapshot)
