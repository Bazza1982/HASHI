"""Standalone WatchTower helper tools."""

