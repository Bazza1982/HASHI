"""Hashi Remote API server."""
from .server import create_app
__all__ = ["create_app"]
