from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any


def default_controlled_hashi_root(runtime_root: Path) -> Path:
    sibling = runtime_root.parent / "HASHI"
    if sibling.exists():
        return sibling.resolve()
    return runtime_root.resolve()


def resolve_controlled_hashi_root(runtime_root: Path, explicit: Path | str | None = None) -> Path:
    if explicit is not None:
        return Path(explicit).expanduser().resolve()
    env_value = os.getenv("WATCHTOWER_CONTROLLED_HASHI_ROOT")
    if env_value:
        return Path(env_value).expanduser().resolve()
    return default_controlled_hashi_root(runtime_root)


def load_target_agents_global(controlled_root: Path | str) -> dict[str, Any]:
    path = Path(controlled_root).expanduser().resolve() / "agents.json"
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
    except Exception:
        return {}
    global_cfg = (data or {}).get("global") or {}
    return dict(global_cfg) if isinstance(global_cfg, dict) else {}
