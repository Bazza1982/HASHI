# HASHI WatchTower

Standalone `WATCHTOWER` sidecar repo for HASHI remote peer presence and rescue
control.

## Identity

- instance id: `WATCHTOWER`
- display name: `HASHI WatchTower`
- default remote port: `43766`
- default controlled core: `C:\Users\thene\projects\HASHI`
- advertised workbench port: `18819` (the controlled `HASHI9` workbench)

`WATCHTOWER` is a separate peer from `HASHI9`. It keeps its own runtime state,
logs, service definition, and instances registry inside this repo while
monitoring and starting the `HASHI9` core in the sibling `HASHI` repo.

## Layout

- runtime state: `state/`
- runtime logs: `logs/`
- remote package: `remote/`
- Windows installer: `bin/install-watchtower-service.ps1`
- health check: `bin/watchtower-healthcheck.ps1`

## Install

```powershell
cd C:\Users\thene\projects\WatchTower
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
powershell -ExecutionPolicy Bypass -File .\bin\install-watchtower-service.ps1
```

To point at a different HASHI core root:

```powershell
powershell -ExecutionPolicy Bypass -File .\bin\install-watchtower-service.ps1 `
  -ControlledHashiRoot "C:\Users\thene\projects\HASHI"
```

The installed service runs:

```text
python -m remote --hashi-root C:\Users\thene\projects\WatchTower --controlled-hashi-root C:\Users\thene\projects\HASHI --instance-id WATCHTOWER --display-name "HASHI WatchTower" --supervised --port 43766 --no-tls --discovery lan --max-terminal-level L3_RESTART
```

## Run Manually

```powershell
cd C:\Users\thene\projects\WatchTower
.\.venv\Scripts\python.exe -m remote --hashi-root . --controlled-hashi-root C:\Users\thene\projects\HASHI --instance-id WATCHTOWER --display-name "HASHI WatchTower" --port 43766 --supervised --no-tls --discovery lan --max-terminal-level L3_RESTART
```

## Uninstall

```powershell
powershell -ExecutionPolicy Bypass -File .\bin\install-watchtower-service.ps1 -Uninstall
```

## Logs

- service stdout: `logs/watchtower-svc-stdout.log`
- service stderr: `logs/watchtower-svc-stderr.log`
- health monitor: `logs/watchtower-health.log`
- rescue start log: `logs/remote_rescue_hashi_start.log`
- rescue audit log: `logs/remote_rescue_audit.jsonl`

## How It Controls HASHI

- reads `C:\Users\thene\projects\HASHI\.bridge_u_f.pid`
- probes the controlled workbench health on port `18819`
- starts `HASHI9` with:
  - `bin/bridge_ctl.ps1 -Action start -Resume`
  - fallback `bin/bridge-u.bat --resume-last --no-pause`

`/control/hashi/start` is gated by `L3_RESTART`. The standalone service
installer sets that level explicitly so WatchTower preserves the current
rescue-start behavior.
